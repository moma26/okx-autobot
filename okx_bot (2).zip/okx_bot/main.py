import ccxt
import time
import os
import pandas as pd
import ta
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv("OKX_API_KEY")
api_secret = os.getenv("OKX_API_SECRET")
api_passphrase = os.getenv("OKX_API_PASSPHRASE")

okx = ccxt.okx({
    'apiKey': api_key,
    'secret': api_secret,
    'password': api_passphrase,
    'enableRateLimit': True,
    'options': {
        'defaultType': 'spot'
    }
})

usdt_balance = 10  # احتياطي بسيط للاختبار
symbols_traded = set()

def fetch_symbols():
    markets = okx.load_markets()
    return [symbol for symbol in markets if symbol.endswith('/USDT') and markets[symbol]['active']]

def fetch_ohlcv(symbol):
    try:
        ohlcv = okx.fetch_ohlcv(symbol, timeframe='1h', limit=100)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        return df
    except Exception as e:
        print(f"Error fetching OHLCV for {symbol}: {e}")
        return None

def apply_indicators(df):
    try:
        df['rsi'] = ta.momentum.RSIIndicator(df['close'], window=14).rsi()
        macd = ta.trend.MACD(df['close'])
        df['macd'] = macd.macd()
        df['macd_signal'] = macd.macd_signal()
        return df
    except Exception as e:
        print(f"Indicator error: {e}")
        return None

def should_buy(df):
    latest = df.iloc[-1]
    return latest['rsi'] < 30 and latest['macd'] > latest['macd_signal']

def place_order(symbol, usdt_amount):
    try:
        price = okx.fetch_ticker(symbol)['ask']
        amount = round(usdt_amount / price, 6)
        order = okx.create_market_buy_order(symbol, amount)
        print(f"BUY ORDER: {symbol} - Amount: {amount}")
        return order
    except Exception as e:
        print(f"Order failed for {symbol}: {e}")
        return None

while True:
    print("Scanning market...")
    all_symbols = fetch_symbols()
    for symbol in all_symbols:
        if symbol in symbols_traded:
            continue

        df = fetch_ohlcv(symbol)
        if df is None or len(df) < 50:
            continue

        df = apply_indicators(df)
        if df is None:
            continue

        if should_buy(df):
            order = place_order(symbol, 4)
            if order:
                symbols_traded.add(symbol)

    print("Sleeping for 15 minutes...")
    time.sleep(900)
